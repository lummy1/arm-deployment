import React from 'react'
import Head from 'next/head';
import PropTypes from 'prop-types';
import { useState, useEffect  } from 'react';
import Breadcrumb from '../../components/breadcrumb';
import HeaderTwo from '../../components/header/header-2';
import AllItems from '../../components/posts/all-items';
import { getAllItems } from '../../lib/items-util';
import { getPostCategories } from '../../lib/getPostCategories';
import { getPostTags } from '../../lib/getPostTags';

const getNews = async () => {
    try {
        const respJSON = await fetch("https://api.marketaux.com/v1/news/all?filter_entities=true&language=en&api_token=AWMKaVr7EHJcPk3SYfz83y9KRyelshdMoLBfstaN");
        const resp = await respJSON.json();
        console.log(resp);
        console.log(resp?.error?.code);

        return resp;
    } catch (error) {
        throw error;
    }
};



const getIndustries = async () => {
    try {
      const respJSON = await fetch(
        'https://api.marketaux.com/v1/entity/industry/list?api_token=AWMKaVr7EHJcPk3SYfz83y9KRyelshdMoLBfstaN'
      );
      const resp = await respJSON.json();
      console.log(resp);
      return resp;
    } catch (error) {
      throw error;
    }
  };


export function getStaticProps() {

    // const [industries, setIndustries] = useState([]);
    // const [news, setNews] = useState([]);

  



    const tags = getPostTags();

    return {
        props: {
            // posts: news,
            // categories,
            // tags,
        },
    };
}

function allItemsPage() {

    const [industries, setIndustries] = useState([]);
    const [news, setNews] = useState([]);

    useEffect(() => {

        (async () => {
            await getNews()
                .then((resp: any) => {
                    console.log(resp);
                    if (resp?.error?.code === 'usage_limit_reached') {
                        console.log(resp.error.message);
                        //displayAlert('error', resp.error.message);
                    } else {
                        setNews(resp.data);
                    }
                })
                .catch((error: any) => {
                    console.log(error);
                });

                await getIndustries()
                    .then((resp: any) => {
                        console.log(resp);
                        if (resp?.error?.code === 'usage_limit_reached') {
                            console.log(resp.error.message);
                            //displayAlert('error', resp.error.message);
                        } else {
                            setIndustries(resp.data);
                        }
                    })
                    .catch((error: any) => {
                        console.log(error);
                    });
        })();       
            
    }, [])

    return (
        <>
            <Head>
                <title>All Posts</title>
                
            </Head>
            <HeaderTwo />
           
            <AllItems posts={news} categories={industries} tags={[]} />
        </>
    );
}

allItemsPage.propTypes = {
    // posts: PropTypes.instanceOf(Object).isRequired,
    // categories: PropTypes.instanceOf(Object).isRequired,
    // tags: PropTypes.instanceOf(Object).isRequired,
};

export default allItemsPage;
