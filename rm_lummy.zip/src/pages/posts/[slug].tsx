import Head from 'next/head';
import PropTypes from 'prop-types';
import { getAllItems, getItemData, getItemsFiles } from '../../lib/items-util';
import { getPostCategories } from '../../lib/getPostCategories';
import { getPostTags } from '../../lib/getPostTags';
import HeaderOne from '../../components/header/header-1';
import PostContent from '../../components/posts/post-detail/post-content';
import PostPageNavigation from '../../components/posts/post-page-navigation';
import { useRouter } from "next/router";
import { useState, useEffect} from 'react'
import Breadcrumb from '../../components/breadcrumb';
import HeaderTwo from '../../components/header/header-2';



// export function getStaticProps(context) {
//     const { params } = context;
//     const { slug } = params;
    
//     console.log(context)
//     console.log(params)
//     console.log(slug)

//     const post = getItemData(slug, 'posts');
//     const posts = getAllItems('posts');
//     const categories = getPostCategories();
//     const tags = getPostTags();
//     const currentPostIndex = posts.findIndex((post) => post.slug === slug);
//     const nextPost = posts[currentPostIndex + 1]
//         ? posts[currentPostIndex + 1]
//         : {};
//     const prevPost = posts[currentPostIndex - 1]
//         ? posts[currentPostIndex - 1]
//         : {};

//     return {
//         props: {
//             post,
//             tags,
//             categories,
//             prevPost,
//             nextPost,
//         },
//     };
// }

// export function getStaticPaths() {
//     const postFilenames = getItemsFiles('posts');

//     const slugs = postFilenames.map((fileName) =>
//         fileName.replace(/\.md$/, '')
//     );

//     return {
//         paths: slugs.map((slug) => ({ params: { slug } })),
//         fallback: false,
//     };
// }



function PostDetailPage() {
    // const { post, tags, categories, prevPost, nextPost } = protrrrreps;
    // console.log(post);

    const getIndustries = async () => {
        try {
          const respJSON = await fetch(
            'https://api.marketaux.com/v1/entity/industry/list?api_token=AWMKaVr7EHJcPk3SYfz83y9KRyelshdMoLBfstaN'
          );
          const resp = await respJSON.json();
          console.log(resp);
          return resp;
        } catch (error) {
          throw error;
        }
      };

    const router = useRouter();
    console.log(router)
    console.log(router?.query)

    const getSingleNews = async () => {
        try {
            console.log(router)
            console.log(router?.query)
            const uuid = router?.query.slug;
            console.log(uuid)
            const respJSON = await fetch(`https://api.marketaux.com/v1/news/uuid/${uuid}?api_token=AWMKaVr7EHJcPk3SYfz83y9KRyelshdMoLBfstaN`);
            const resp = await respJSON.json();
            console.log(resp)
            return resp;
        } catch (error) {
            throw error;
        }
    };

    const [industries, setIndustries] = useState([]);
    const [news, setNews] = useState({});

    useEffect(() => {

        (async () => {
            await getSingleNews()
                .then((resp: any) => {
                    console.log(resp);
                    if (resp?.error?.code) {
                        console.log(resp.error.message);
                        //displayAlert('error', resp.error.message);
                    } else {
                        setNews(resp);
                    }
                })
                .catch((error: any) => {
                    console.log(error);
                });

                await getIndustries()
                    .then((resp: any) => {
                        console.log(resp);
                        if (resp?.error?.code === 'usage_limit_reached') {
                            console.log(resp.error.message);
                            //displayAlert('error', resp.error.message);
                        } else {
                            setIndustries(resp.data);
                        }
                    })
                    .catch((error: any) => {
                        console.log(error);
                    });
        })();       
            
    }, [])
    return (
        <>
            <Head>
                <title>{news.title}</title>
                <meta name="description" content={news.title} />
            </Head>
            <HeaderTwo />
            
            <PostContent post={news} categories={industries} tags={[]} />
            
            {/* <PostPageNavigation prevPost={prevPost} nextPost={nextPost} /> */}
        </>
    );
}

PostDetailPage.propTypes = {
    post: PropTypes.instanceOf(Object),
    tags: PropTypes.instanceOf(Object),
    categories: PropTypes.instanceOf(Object),
    // prevPost: PropTypes.instanceOf(Object).isRequired,
    // nextPost: PropTypes.instanceOf(Object).isRequired,
};

export default PostDetailPage;
