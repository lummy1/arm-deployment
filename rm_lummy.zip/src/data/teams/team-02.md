---
id: 'team-02'
title: Team Member
image: /images/team/2.jpg
twitterIcon: 'FaTwitter'
facebookIcon: 'FaFacebookF'
instagramIcon: 'FaInstagram'
linkedinIcon: 'FaLinkedin'
memberName: Tom Holland
designation: Architect & Project Management
---
