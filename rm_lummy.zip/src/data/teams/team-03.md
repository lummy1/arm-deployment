---
id: 'team-03'
title: Team Member
image: /images/team/3.jpg
twitterIcon: 'FaTwitter'
facebookIcon: 'FaFacebookF'
instagramIcon: 'FaInstagram'
linkedinIcon: 'FaLinkedin'
memberName: Laura Erakovic
designation: Executive & Marketing Management
---
