---
id: 'team-01'
title: Team Member
image: /images/team/1.jpg
twitterIcon: 'FaTwitter'
facebookIcon: 'FaFacebookF'
instagramIcon: 'FaInstagram'
linkedinIcon: 'FaLinkedin'
memberName: Edward Eric Jr
designation: CEO Founder
---
