---
id: 'pricing-item-03'
monthlyPlan: 'Pro'
annualPlan: 'Basic'
monthlyPrice: '$29'
annualPrice: '$24'
icon: 'AiOutlineCheckCircle'
monthlyExcerpt: Free with 14 days trial, then you can choose plan
annualExcerpt: For the first year with 30-days money-back guarantee
monthlyPricingList:
    - 10 User
    - 5 Dashboard
    - 15 Projects
annualPricingList:
    - 20 Users
    - Unlimited Dashboard
    - 50 Projects
    - Custome CSS + HTML
---
