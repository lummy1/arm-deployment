---
id: 'pricing-item-04'
monthlyPlan: 'Basic'
annualPlan: 'Pro'
monthlyPrice: '$17'
annualPrice: '$99'
icon: 'AiOutlineCheckCircle'
monthlyExcerpt: Free with 14 days trial, then you can choose plan
annualExcerpt: For the first year with 30-days money-back guarantee
monthlyPricingList:
    - 1 User
    - 1 Dashboard
    - 5 Projects
annualPricingList:
    - 3 Users
    - Unlimited Dashboard
    - 50 Projects
    - Custome CSS
---
