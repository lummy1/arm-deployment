---
id: 'testimonial-02'
quote: 'FaQuoteRight'
authorName: Bobs Hanley
authorOccupation: / Director at Spotify
excerpt: Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino staveuo at magna akal semper Fusce commodo molestie luctus. Lorem ipsum ulicon Dolor tusima olatiup.
---
