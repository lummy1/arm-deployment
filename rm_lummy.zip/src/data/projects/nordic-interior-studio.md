---
title: 'Nordic Interior Studio'
category: 'residenital'
date: '2022-01-12'
image: nordic.jpg
descriptionImg: '1.jpg'
excerpt: Copper Brass
location: Calle Blancos, Costa Rica
clientName: Alex Stinson
completedDate: January 2022
architectName: Rob Kenny
squareUnits: 1,560 sqr
additionDesc: Edden’s Villa Is An International Project Located In Costa Rica. It Has Various Different Levels, Whom Are Embedded Into The Unevenness Of The Terrain. This Project Seeks To Integrate Passive Strategies For Energy Saving, Such As The Inclusion Of As Much Natural Light As Possible As Well As Having Green Roofs With Lots Of Vegetation In Them. <br/> The Geometry Of This House Combines Design With Nature Into The Structure Of The House, Which Makes It Unique Amongst Other Neighboring Places.
isFeatured: true
---
