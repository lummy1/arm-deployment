---
title: 'Inspired From China In Web Design'
category: 'commercial'
date: '2022-01-12'
image: inspired.jpg
descriptionImg: '1.jpg'
excerpt: Commercial
location: Calle Blancos, Costa Rica
clientName: Alex Stinson
completedDate: January 2022
architectName: Rob Kenny
squareUnits: 1,560 sqr
additionDesc: Edden’s Villa Is An International Project Located In Costa Rica. It Has Various Different Levels, Whom Are Embedded Into The Unevenness Of The Terrain. This Project Seeks To Integrate Passive Strategies For Energy Saving, Such As The Inclusion Of As Much Natural Light As Possible As Well As Having Green Roofs With Lots Of Vegetation In Them. <br/> The Geometry Of This House Combines Design With Nature Into The Structure Of The House, Which Makes It Unique Amongst Other Neighboring Places.
isFeatured: true
---
