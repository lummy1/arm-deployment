---
id: 'hero-01'
title: Hero Image
image: /images/hero/1.jpg
heroYear: 2022
twitterIcon: 'FaTwitter'
facebookIcon: 'FaFacebookF'
googleIcon: 'FaGoogle'
heroCategory: Rustic interior <br /> studio
heroTitle: Rustic and <br /> Modern
heroContactInfo: contact@Rustictudio.co
---
