export const OffcanvasData = [
    {
        id: 'menu-01',
        title: 'Home',
        path: '/',
        cName: 'offcanvas-text',
    },
    {
        id: 'menu-02',
        title: 'About',
        path: '/about',
        cName: 'offcanvas-text',
    },
    {
        id: 'menu-03',
        title: 'Projects',
        path: '/projects',
        cName: 'offcanvas-text',
    },
    {
        id: 'menu-04',
        title: 'Posts',
        path: '/posts',
        cName: 'offcanvas-text',
    },
    {
        id: 'menu-05',
        title: 'Contact',
        path: '/contact',
        cName: 'offcanvas-text',
    },
];
